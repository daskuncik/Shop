﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gateway.Models
{
    public class SubscriptionsModel
    {
        public List<string> Authors { get; set; }
        public string User { get; set; }

    }
}
