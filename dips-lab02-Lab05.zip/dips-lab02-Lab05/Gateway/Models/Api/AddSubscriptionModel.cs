﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gateway.Models
{
    public class AddSubscriptionModel
    {
        public string Author { get; set; }
    }
}
